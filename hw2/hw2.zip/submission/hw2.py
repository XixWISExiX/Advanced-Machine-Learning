'''
Advanced Machine Learning, 2025
Homework 2

Building predictors for brain-machine interfaces

Author: Andrew H. Fagg
Modified by: Alan Lee
'''
# Standard libraries
import tensorflow as tf
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import time
import wandb
import socket
import keras

import pickle
import argparse
import os
import sys


# Keras3 way of doing things
from keras.layers import InputLayer, Dense
from keras.models import Sequential
from keras.utils import plot_model


# Location for libraries (you will likely just use './')
tf_tools = "distribute/"

sys.path.append(tf_tools)


# Helper Files
from deep_networks import *
from symbiotic_metrics import *
from job_control import *
from aggregate_stats import *



#################################################################
# Default plotting parameters
FONTSIZE = 18
plt.rcParams['figure.figsize'] = (10, 6)
plt.rcParams['font.size'] = FONTSIZE

#################################################################
def extract_data(bmi:dict, args:argparse.ArgumentParser)->[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray,
                                                          np.ndarray, np.ndarray, np.ndarray, np.ndarray, dict]:
    '''
    Translate BMI data structure from the file into a data set for training/evaluating a single model
    
    :param bmi: Dictionary containing the full BMI data set, as loaded from the pickle file.
    :param args: Argparse object, which contains key information, including Nfolds, 
            predict_dim, output_type, rotation
            
    :return: Numpy arrays in standard TF format for training set input/output, 
            validation set input/output and testing set input/output; and a
            dictionary containing the lists of folds that have been chosen
    '''
    # Number of folds in the data set
    ins = bmi['MI']
    Nfolds = len(ins)
    
    times = bmi['time']
    
    # Check that argument matches actual number of folds
    assert (Nfolds == args.Nfolds), "Nfolds must match folds in data set"
    
    # Pull out the data to be predicted
    outs = bmi[args.output_type]
    
    # Check that predict_dim is valid
    assert (args.predict_dim is None or (args.predict_dim >= 0 and args.predict_dim < outs[0].shape[1]))
    
    # Rotation and number of folds to use for training
    r = args.rotation

    # Number of training folds
    Ntraining = args.Ntraining
    
    # Compute which folds belong in which set
    folds_training = (np.array(range(Ntraining)) + r) % Nfolds
    folds_validation = (np.array([Nfolds-2]) + r ) % Nfolds
    folds_testing = (np.array([Nfolds-1]) + r) % Nfolds
    
    # Log these choices
    folds = {'folds_training': folds_training, 'folds_validation': folds_validation,
            'folds_testing': folds_testing}
    
    # Combine the folds into training/val/test data sets (pairs of input/output numpy arrays)
    ins_training = np.concatenate([ins[i] for i in folds_training], axis=0)
    outs_training = np.concatenate([outs[i] for i in folds_training], axis=0)
    time_training = np.concatenate([times[i] for i in folds_training], axis=0)
        
    ins_validation = np.concatenate([ins[i] for i in folds_validation], axis=0)
    outs_validation = np.concatenate([outs[i] for i in folds_validation], axis=0)
    time_validation = np.concatenate([times[i] for i in folds_validation], axis=0)
        
    ins_testing = np.concatenate([ins[i] for i in folds_testing], axis=0)
    outs_testing = np.concatenate([outs[i] for i in folds_testing], axis=0)
    time_testing = np.concatenate([times[i] for i in folds_testing], axis=0)
    
    # If a particular output dimension is specified, then extract it from the outputs
    if args.predict_dim is not None:
        outs_training = outs_training[:,[args.predict_dim]]
        outs_validation = outs_validation[:,[args.predict_dim]]
        outs_testing = outs_testing[:,[args.predict_dim]]
    
    return ins_training, outs_training, time_training, ins_validation, outs_validation, time_validation, ins_testing, outs_testing, time_testing, folds



def exp_type_to_hyperparameters(args:argparse.ArgumentParser):
    '''
    Translate the exp_type into a hyperparameter set

    :param args: ArgumentParser
    :return: Hyperparameter set (in dictionary form)
    '''
    # NOTE (useful for having multiple Cartesian product parameter sets)
    
    if args.exp_type == 'bmi':
        p = {'Ntraining': [1, 2, 3, 4, 6, 8, 11, 14, 18],
             'rotation': [0, 2, 4, 6, 8, 10, 12, 14, 16, 18],
             'L2_regularization': [0.1, 0.01, 0.001, 0.0001, 0.00001]}
    else: 
        assert False, "Bad exp_type"

    return p

def augment_args(args:argparse.ArgumentParser):
    '''
    Use the jobiterator to override the command-line arguments based on the experiment index. 

    @return A string representing the selection of parameters to be used in the file name
    '''
    index = args.exp_index
    if(index is None):
        # UPDATE
        return "Ntraining_%d_rotation_%d"%(args.Ntraining, args.rotation)
    
    # Create parameter sets to execute the experiment on.  This defines the Cartesian product
    #  of experiments that we will be executing
    p = exp_type_to_hyperparameters(args)

    # Create the iterator
    ji = JobIterator(p)
    print("Total jobs:", ji.get_njobs())
    
    # Check bounds
    assert (args.exp_index >= 0 and args.exp_index < ji.get_njobs()), "exp_index out of range"

    # Print the parameters specific to this exp_index
    print(ji.get_index(args.exp_index))
    
    # Push the attributes to the args object and return a string that describes these structures
    return ji.set_attributes_by_index(args.exp_index, args)
    
def generate_fname(args, params_str):
    '''
    Generate the base file name for output files/directories.
    
    The approach is to encode the key experimental parameters in the file name.  This
    way, they are unique and easy to identify after the fact.
    
    Expand this as needed
    '''
    # Hidden unit configuration
    hidden_str = '_'.join(str(x) for x in args.hidden)
    
    # Dimension being predicted
    if args.predict_dim is None:
        predict_str = args.output_type
    else:
        predict_str = '%s_%d'%(args.output_type, args.predict_dim)

    if args.L1_regularization is not None:
        Lx_str = '_L1_%f'%args.L1_regularization
        
    elif args.L2_regularization is not None:
        Lx_str = '_L2_%f'%args.L2_regularization
    else:
        Lx_str = ''
        
    # Put it all together, including #of training folds and the experiment rotation
    return "%s/%s_%s_%s%s_hidden_%s_%s"%(args.results_path, args.exp_type, args.label,
                                       predict_str, Lx_str, hidden_str, params_str)



def execute_exp(args:argparse.ArgumentParser=None):
    '''
    Perform the training and evaluation for a single model
    
    @args Argparse arguments
    '''
    # Check the arguments
    if args is None:
        # Case where no args are given (usually, because we are calling from within Jupyter)
        #  In this situation, we just use the default arguments
        parser = create_parser()
        args = parser.parse_args([])
        
    # Modify the args if an exp_index is specified
    params_str = augment_args(args)
    
    print("Params:", params_str)
    
    # Compute output file name base
    fbase = generate_fname(args, params_str)
    
    print("File name base:", fbase)

    # Output pickle file name
    fname_out = "%s_results.pkl"%(fbase)

    # Check if this file exists
    if not args.force and os.path.exists(fname_out):
        # File exists: abort the run
        print("File already exists")
        return None
    
    # Load the data
    bmi = None
    with open(args.dataset, "rb") as fp:
        bmi = pickle.load(fp)

    assert bmi is not None, "Unable to load data"

    # Extract the data sets.  This process uses rotation and Ntraining (among other exp args)
    ins_training, outs_training, time_training, ins_validation, outs_validation, time_validation, ins_testing, outs_testing, time_testing, folds = extract_data(bmi, args)
    

    # Is this a test run?
    if(args.nogo):
        # Don't execute the experiment
        print("Test run only")
        return None
    
    # Start wandb
    if not args.nowandb:
        run = wandb.init(project=args.project,
                         name='%s_%s_%s%s_NT%02d%s_R%d'%(args.exp_type,
                                                         args.label,
                                                         args.output_type,
                                                         "" if args.predict_dim is None else "_%d"%args.predict_dim,
                                                         args.Ntraining,
                                                         "" if args.exp_index is None else "_IN_%03d"%args.exp_index,
                                                         args.rotation),
                         notes=fbase,
                         config=vars(args))

        # Log hostname
        wandb.log({'hostname': socket.gethostname()})

    # Metrics
    fvaf = FractionOfVarianceAccountedForSingle(outs_training.shape[1])
    rmse = keras.metrics.RootMeanSquaredError()

    # Build the model: you are responsible for providing this function
    model = deep_network_basic(ins_training.shape[1], tuple(args.hidden), outs_training.shape[1],     
                               activation=args.activation_hidden,
                               lrate=args.lrate,
                               activation_out=args.activation_out,
                               kernel_regularizer = args.L2_regularization,
                               kernel_regularizer_L1 = args.L1_regularization,
                               dropout=args.dropout,
                               metrics=[fvaf, rmse])
    
    # Report if verbosity is turned on
    if args.verbose >= 1:
        print(model.summary())

    if args.render:
        fname = '%s_model_plot.png'%fbase
        plot_model(model, to_file=fname, show_shapes=True, show_layer_names=True)
        if not args.nowandb:
            wandb.log({'model architecture': wandb.Image(fname)})
    
    # Callbacks
    cbs = []
    early_stopping_cb = keras.callbacks.EarlyStopping(patience=args.patience,
                                                      restore_best_weights=True,
                                                      min_delta=args.min_delta)
    cbs.append(early_stopping_cb)

    # WandB callback
    if not args.nowandb:
        wandb_metrics_cb = wandb.keras.WandbMetricsLogger()
        cbs.append(wandb_metrics_cb)
    
    # Learn
    history = model.fit(x=ins_training,
                        y=outs_training,
                        epochs=args.epochs,
                        verbose=args.verbose>=2,
                        validation_data=(ins_validation, outs_validation), 
                        callbacks=cbs)
        
    # Generate log data
    results = {}
    results['args'] = args
    
    results['predict_training'] = model.predict(ins_training)
    # evaluate returns a tuple: (loss, fvaf, rmse)
    #results['predict_training_eval'] = model.evaluate(ins_training, outs_training)
    results['predict_training_eval_loss'], results['predict_training_eval_fvaf'], results['predict_training_eval_rmse'] = model.evaluate(ins_training, outs_training)

    results['outs_training'] = outs_training
    results['time_training'] = time_training
    if not args.nowandb:
        wandb.log({
            'loss_training': results['predict_training_eval_loss'],
            'fvaf_training': results['predict_training_eval_fvaf'],
            'rmse_training': results['predict_training_eval_rmse'],
        })
    
    results['predict_validation'] = model.predict(ins_validation)
    #results['predict_validation_eval'] = model.evaluate(ins_validation, outs_validation)
    results['predict_validation_eval_loss'], results['predict_validation_eval_fvaf'], results['predict_validation_eval_rmse'] = model.evaluate(ins_validation, outs_validation)
    results['outs_validation'] = outs_validation
    results['time_validation'] = time_validation
    if not args.nowandb:
        wandb.log({
            'loss_validation': results['predict_validation_eval_loss'],
            'fvaf_validation': results['predict_validation_eval_fvaf'],
            'rmse_validation': results['predict_validation_eval_rmse'],
        })
    
    results['predict_testing'] = model.predict(ins_testing)
    #results['predict_testing_eval'] = model.evaluate(ins_testing, outs_testing)
    results['predict_testing_eval_loss'], results['predict_testing_eval_fvaf'], results['predict_testing_eval_rmse'] = model.evaluate(ins_testing, outs_testing)
    results['outs_testing'] = outs_testing
    results['time_testing'] = time_testing

    if not args.nowandb:
        for t in range(len(results['predict_testing'])):
            wandb.log({
                'predict_testing': results['predict_testing'][t],
                'outs_testing': results['outs_testing'][t],
                'time_testing': results['time_testing'][t],
            })
    
    if not args.nowandb:
        wandb.log({
            'loss_testing': results['predict_testing_eval_loss'],
            'fvaf_testing': results['predict_testing_eval_fvaf'],
            'rmse_testing': results['predict_testing_eval_rmse'],
            'training_size': len(ins_training),
            'validation_size': len(ins_validation),
            'test_size': len(ins_testing)
        })
    
    
    results['history'] = history.history
    
    # Save results
    results['fname_base'] = fbase
    with open(fname_out, "wb") as fp:
        pickle.dump(results, fp)
    
    # Save the model (can't be included in the pickle file)
    if args.save:
        model.save("%s_model.keras"%(fbase))

    # Close out wandb
    if not args.nowandb:
        wandb.finish()

    return model
               
def create_parser()->argparse.ArgumentParser:
    # Parse the command-line arguments
    parser = argparse.ArgumentParser(description='BMI Learner', fromfile_prefix_chars='@')

    # Problem definition
    parser.add_argument('--dataset', type=str, default='/home/fagg/datasets/bmi/bmi_dataset.pkl', help='Data set file')
    parser.add_argument('--output_type', type=str, default='torque', help='Type to predict')
    parser.add_argument('--predict_dim', type=int, default=None, help="Dimension of the output to predict")
    parser.add_argument('--Nfolds', type=int, default=20, help='Maximum number of folds')

    # Network details
    parser.add_argument('--activation_out', type=str, default=None, help='Activation for output layer')
    parser.add_argument('--activation_hidden', type=str, default=None, help='Activation for hidden layers')
    parser.add_argument('--hidden', nargs='+', type=int, default=[10, 5], help='Number of hidden units per layer (sequence of ints)')

    # Experiment details
    parser.add_argument('--rotation', type=int, default=0, help='Cross-validation rotation')
    parser.add_argument('--epochs', type=int, default=1000, help='Training epochs')
    parser.add_argument('--Ntraining', type=int, default=2, help='Number of training folds')

    # Meta experiment details
    parser.add_argument('--exp_type', type=str, default='bmi', help='High level name for this set of experiments; selects the specific Cartesian product')
    parser.add_argument('--exp_index', type=int, default=None, help='Experiment index for Cartesian experiment')
    parser.add_argument('--label', type=str, default='', help='Label used for fnames and WandB')

    # Training parameters
    parser.add_argument('--lrate', type=float, default=0.001, help="Learning rate")

    parser.add_argument('--dropout', type=float, default=None, help="Dropout rate")
    parser.add_argument('--L1_regularization', '--l1', type=float, default=None, help="L1 regularization factor (only active if no L2)")
    parser.add_argument('--L2_regularization', '--l2', type=float, default=None, help="L2 regularization factor")

    # Early stopping
    parser.add_argument('--min_delta', type=float, default=0.001, help="Minimum delta for early termination")
    parser.add_argument('--patience', type=int, default=100, help="Patience for early termination")

    # WandB
    parser.add_argument('--nowandb', action='store_true', help='Do not use Weights and Biases')
    
    # Computer config
    parser.add_argument('--gpu', action='store_true', help='Use a GPU')
    parser.add_argument('--cpus_per_task', type=int, default=None, help='Number of threads to use')

    # Results
    parser.add_argument('--results_path', type=str, default='./results', help='Results directory')
    parser.add_argument('--verbose', '-v', action='count', default=0, help="Verbosity level")
    
    parser.add_argument('--save', action='store_true', help='Save model')
    parser.add_argument('--render', action='store_true', help='Render the model')
    

    # Execution control
    parser.add_argument('--nogo', action='store_true', help='Do not perform the experiment')
    parser.add_argument('--check', action='store_true', help='Check results for completeness')
    parser.add_argument('--generate_loss_metric_plots', action='store_true', help='Create Loss Metric Plots')
    parser.add_argument('--force', action='store_true', help='Dont skip execution if a file already exists')
    parser.add_argument('--meta', action='store_true', help='Aggregates individual experiments into a form that will be easier to manipulate (pandas DF). This should be used after running an experiment batch.')

    # WandB
    parser.add_argument('--project', type=str, default='HW1', help='WandB project name')
    
    return parser

def check_args(args:argparse.ArgumentParser):
    '''
    Check that key arguments are within appropriate bounds.  Failing an assert causes a hard failure with meaningful output
    '''
    assert (args.rotation >= 0 and args.rotation < args.Nfolds), "Rotation must be between 0 and Nfolds"
    assert (args.Ntraining >= 1 and args.Ntraining < (args.Nfolds-2)), "Ntraining must be between 1 and Nfolds-2"
    assert (args.lrate > 0.0 and args.lrate < 1), "Lrate must be between 0 and 1"


def check_completeness(args:argparse.ArgumentParser):
    '''
    Check the completeness of a Cartesian product run.

    All other args should be the same as if you executed your batch, however, the '--check' flag has been set

    Prints a report of the missing runs, including both the exp_index and the name of the missing results file

    :param args: ArgumentParser
    
    '''
    
    # Get the corresponding hyperparameters
    p = exp_type_to_hyperparameters(args)

    # Create the iterator
    ji = JobIterator(p)

    print("Total jobs: %d"%ji.get_njobs())

    print("MISSING RUNS:")

    indices = []
    # Iterate over all possible jobs
    for i in range(ji.get_njobs()):
        params_str = ji.set_attributes_by_index(i, args)
        # Compute output file name base
        fbase = generate_fname(args, params_str)
    
        # Output pickle file name
        fname_out = "%s_results.pkl"%(fbase)

        if not os.path.exists(fname_out):
            # Results file does not exist: report it
            print("%3d\t%s"%(i, fname_out))
            indices.append(i)

    # Give the list of indices that can be inserted into the --array line of the batch file
    print("Missing indices (%d): %s"%(len(indices),','.join(str(x) for x in indices)))



# NOTE filename is currently not dynamic, so it must manually be set
def generate_loss_metric_plots(result_path:str):
    '''
    Function that generates a loss metric plot for the metrics favf and rmse

    :param result_path: Result Path of Generated Plots
    '''

    training_set_size_arr = []

    fvaf_testing_arr = []
    fvaf_validation_arr = []
    fvaf_training_arr = []

    rmse_testing_arr = []
    rmse_validation_arr = []
    rmse_training_arr = []

    for ntraining in [1, 2, 3, 4, 6, 8, 11, 14, 18]:
        filename = '%s/bmi_exp_batch_1_dtheta_0_hidden_1000_800_600_400_200_100_JI_Ntraining_%d_rotation_15_results.pkl'%(result_path, ntraining)


        with open(filename, 'rb') as f:
            results = pickle.load(f)

        training_set_size_arr.append(results['args'].Ntraining)

        fvaf_testing_arr.append(results['predict_testing_eval'][1])
        fvaf_validation_arr.append(results['predict_validation_eval'][1])
        fvaf_training_arr.append(results['predict_training_eval'][1])

        rmse_testing_arr.append(results['predict_testing_eval'][2])
        rmse_validation_arr.append(results['predict_validation_eval'][2])
        rmse_training_arr.append(results['predict_training_eval'][2])

    # Start wandb
    if not args.nowandb:
        wandb.init(project=args.project,name="fvaf-and-rmse-plots")

#### fvaf plot ####
    fig, ax = plt.subplots() 

    # Plot metrics
    ax.plot(training_set_size_arr, fvaf_training_arr, label='training fvaf', color='black', marker='o')
    ax.plot(training_set_size_arr, fvaf_validation_arr, label='validation fvaf', color='green', marker='x')
    ax.plot(training_set_size_arr, fvaf_testing_arr, label='testing fvaf', color='red', marker='s')
    
    # Add Labels
    ax.set_xlabel('Training Set Size')
    ax.set_ylabel('fvaf')
    ax.set_title('fvaf vs Training Set Size')
    ax.legend()

    save_location = '%s/fvaf_plot.png'%(result_path)
    fig.savefig(save_location)

    if not args.nowandb:
        wandb.log({'fvaf_plot': wandb.Image(fig)})

    plt.close(fig)

#### rmse plot ####
    fig, ax = plt.subplots() 

    # Plot metrics
    ax.plot(training_set_size_arr, rmse_training_arr, label='training rmse', color='black', marker='o')
    ax.plot(training_set_size_arr, rmse_validation_arr, label='validation rmse', color='green', marker='x')
    ax.plot(training_set_size_arr, rmse_testing_arr, label='testing rmse', color='red', marker='s')
    
    # Add Labels
    ax.set_xlabel('Training Set Size')
    ax.set_ylabel('rmse')
    ax.set_title('rmse vs Training Set Size')
    ax.legend()

    save_location = '%s/rmse_plot.png'%(result_path)
    fig.savefig(save_location)

    if not args.nowandb:
        wandb.log({'rmse_plot': wandb.Image(fig)})

    plt.close(fig)

    # Close out wandb
    if not args.nowandb:
        wandb.finish()

#################################################################
if __name__ == "__main__":
    parser = create_parser()
    args = parser.parse_args()
    check_args(args)

    # Turn off GPUs?
    if not args.gpu or "CUDA_VISIBLE_DEVICES" not in os.environ.keys():
        tf.config.set_visible_devices([], 'GPU')
        print('NO VISIBLE DEVICES!!!!')


    # GPU check
    visible_devices = tf.config.get_visible_devices('GPU')
    n_visible_devices = len(visible_devices)

    print('GPUS:', visible_devices)
    if(n_visible_devices > 0):
        for device in visible_devices:
            tf.config.experimental.set_memory_growth(device, True)
        print('We have %d GPUs\n'%n_visible_devices)
    else:
        print('NO GPU')

    # Set number of threads, if it is specified
    if args.cpus_per_task is not None:
        tf.config.threading.set_intra_op_parallelism_threads(args.cpus_per_task)
        tf.config.threading.set_inter_op_parallelism_threads(args.cpus_per_task)

    # Which job to do?
    if(args.check):
        # Just look at which results files have NOT been created yet
        check_completeness(args)

    elif(args.generate_loss_metric_plots):
        # Create loss metric plots
        generate_loss_metric_plots(args.results_path)

    elif(args.meta):
        # All of the results to pull out of the results pickle file.  Note: these must be scalars!
        results_keys = ['predict_testing_eval_loss', 'predict_testing_eval_fvaf', 'predict_testing_eval_rmse',
                        'predict_validation_eval_loss', 'predict_validation_eval_fvaf', 'predict_validation_eval_rmse',
                        'predict_training_eval_loss', 'predict_training_eval_fvaf', 'predict_training_eval_rmse']

        #results_keys = ['predict_testing_eval', 'predict_validation_eval', 'predict_training_eval']
        # All of the experiment configuration data to pull out of the pickle file.  These must be scalars, too!
        exp_keys = ['exp_type', 'L1_regularization', 'L2_regularization', 'label', 'Ntraining', 'output_type',
                    'predict_dim', 'dropout', 'exp_index', 'rotation']

        # Use jobiterator to load each of the corresponding pkl files and construct a dataframe
        df = aggregate_stats(args, results_keys, exp_keys)
        print(df.columns)
        print(df[['Ntraining', 'predict_testing_eval_fvaf', 'L2_regularization']])

        # Construct output file name for the created df
        fname = '%s/%s_%s_aggregate.pkl'%(args.results_path, args.label, args.exp_type)

        # Write the file
        with open(fname, "wb") as fp:
            pickle.dump(df, fp)

    else:
        # Do the work
        execute_exp(args)
